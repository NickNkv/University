#include <iostream>
#include <exception>
#include "Date.h"

int main()
{
    try {
        Date date(25, 4, 2026);
        Date date2(22, 4, 2026);
        std::cout << date << "\n";
        date.addDays(10);
        std::cout << date;

    }
    catch (std::exception& e) {
        std::cout << e.what();
    }
    catch (...) {
        std::cout << "Error!";
    }

    return 0;
}